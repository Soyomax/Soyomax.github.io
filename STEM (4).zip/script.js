body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f0f0f0;
    color: #333;
}

header {
    background-color: #1d3661;
    color: #fff;
    padding: 20px;
    text-align: center;
}

h1 {
    margin: 0;
}

main {
    padding: 20px;
}

footer {
    background-color: #1d3661;
    color: #fff;
    padding: 10px;
    text-align: center;
    position: fixed;
    bottom: 0;
    width: 100%;
}
